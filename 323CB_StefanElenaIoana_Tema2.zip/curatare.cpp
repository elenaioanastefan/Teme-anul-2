#include <bits/stdc++.h>
#define MAX 1005

using namespace std;

/* Deschid fisierele de intrare si de iesire */
ifstream fin("curatare.in");
ofstream fout("curatare.out");

struct Nod {
    int i, j;
};

int n, m;
string s[MAX];
int dist[4][MAX][MAX];
int vizitat[MAX][MAX];
/* Vectori folositi pentru deplasarea pe grid */
int di[] = {0, 0, 1, -1};
int dj[] = {1, -1, 0, 0};
int stiva[10];
int inStiva[10];
int permutare[10];
int distribuire[10];
int result = 2e9;
Nod coada[3 * MAX * MAX];
vector<Nod> robotei, murdarii;

/* Calculez timpii de finisare pentru fiecare robotel */
void rezolvaDistribuire() {
    vector<Nod> pozitie = robotei;
    vector<int> timpFinisaj(robotei.size(), 0);
    for (int i = 0; i < murdarii.size(); i++) {
        Nod murdarie = murdarii[permutare[i]];
        Nod robotel = pozitie[distribuire[i]];

        timpFinisaj[distribuire[i]] += dist[permutare[i]][robotel.i][robotel.j];
        pozitie[distribuire[i]] = murdarie;
    }

    int timpFinisajMax = 0;
    for (auto it : timpFinisaj) {
        if (it > timpFinisajMax) {
            timpFinisajMax = it;
        }
    }

    result = min(result, timpFinisajMax);
}

/* Distribuire zone murdare */
void rezolvaPermutare(int p) {
    if (p == murdarii.size()) {
        rezolvaDistribuire();
        return;
    }

    for (int i = 0; i < robotei.size(); i++) {
        distribuire[p] = i;
        rezolvaPermutare(p + 1);
    }
}

/* Permutari */
void backtrack(int p) {
    if (p == murdarii.size()) {
        rezolvaPermutare(0);
        return;
    }

    for (int i = 0; i < murdarii.size(); i++) {
        if (!inStiva[i]) {
            permutare[p] = i;
            inStiva[i] = 1;
            backtrack(p + 1);
            inStiva[i] = 0;
        }
    }
}

int main() {
    /* Citesc datele din fisierul de intrare */
    fin >> n >> m;

    for (int i = 1; i <= n; i++) {
        fin >> s[i];
        s[i] = '_' + s[i];

        for (int j = 1; j <= m; j++) {
            if (s[i][j] == 'S') {
                /* Adaug in vectorul pentru spatiile murdare */
                murdarii.push_back({i, j});
            } else if (s[i][j] == 'R') {
                /* Adaug in vectorul pentru robotei */
                robotei.push_back({i, j});
            }
        }
    }

    /* Inchid fisierul de intrare */
    fin.close();

    /* Functie care verifica daca indicii sunt in limite  */
    auto inside = [&](Nod u) {
        return u.i >= 1 && u.j >= 1 && u.i <= n && u.j <= m;
    };

    /* Calculez distantele de la fiecare spatiu murdar
     * utilizand parcurgerea BFS 
     */
    for (int k = 0; k < murdarii.size(); k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                /* Initializez vectorii de distanta si vizitare */
                dist[k][i][j] = -1;
                vizitat[i][j] = 0;
            }
        }

        int st = 1, dr = 0;
        /* Adaug in coada spatiile murdare parcurse */
        coada[++dr] = murdarii[k];
        /* Setez spatiul murdar ca fiind vizitat */
        vizitat[murdarii[k].i][murdarii[k].j] = 1;
        /* Distanta initial este 0 */
        dist[k][murdarii[k].i][murdarii[k].j] = 0;

        while (st <= dr) {
            Nod tata = coada[st++];

            for (int p = 0; p < 4; p++) {
                int i = tata.i + di[p];
                int j = tata.j + dj[p];

                /* Verific daca ma aflu in limite cu indicii si 
                 * daca inca nu am vizitat nodul respectiv, considerand
                 * ca poate fi vizitat (nu este spatiu ocupat)
                 */
                if (inside({i, j}) && !vizitat[i][j] && s[i][j] != 'X') {
                    Nod fiu = {i, j};
                    /* Setez nodul ca fiind vizitat */
                    vizitat[fiu.i][fiu.j] = 1;
                    /* Actualizez distanta */
                    dist[k][fiu.i][fiu.j] = dist[k][tata.i][tata.j] + 1;
                    /* Adaug nodul in coada */
                    coada[++dr] = fiu;
                }
            }
        }
    }

    /* Folosind backtracking, calculez durata minima, retinuta in result */
    backtrack(0);

    fout << result;

    /* Inchid fisierul de iesire */
    fout.close();

    return 0;
}
/*
 * Stefan Elena-Ioana 323CB
 */
