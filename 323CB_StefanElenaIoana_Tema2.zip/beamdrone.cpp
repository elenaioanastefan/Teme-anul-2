#include <bits/stdc++.h>
#define MAX 1005

using namespace std;

/* Deschid fisierele de intrare si de iesire */
ifstream fin("beamdrone.in");
ofstream fout("beamdrone.out");

struct Nod {
    int i, j;
    /* Codific orientarea orizontala cu 0, iar cea verticala cu 1 */
    int orientare;

    bool operator == (const Nod& other) const {
        return i == other.i && j == other.j;
    }
};

/* Vectori folositi pentru deplasarea pe grid */
int di[] = {0, 0, 1, -1};
int dj[] = {1, -1, 0, 0};
int n, m;
Nod start, finis;
string s[MAX];
Nod coada[9 * MAX * MAX];
int cost[2][MAX][MAX];

int main() {
    /* Citesc datele din fisierul de intrare */
    fin >> n >> m;
    fin >> start.i >> start.j;
    fin >> finis.i >> finis.j;

    for (int i = 0; i < n; i++) {
        fin >> s[i];
    }

    /* Inchid fisierul de intrare */
    fin.close();

    /* Functie care verifica daca indicii sunt in limite  */
    auto good = [&](Nod u) {
        return u.i >= 0 && u.j >= 0 && u.i < n && u.j < m && s[u.i][u.j] != 'W';
    };

    /* Gasesc noua orientare + cost (+1 daca schimb directia) */
    auto getFiu = [&](Nod u, Nod v) -> pair<Nod, int> {
        int c;
        if (u.orientare == 0 && u.i == v.i) {
            v.orientare = u.orientare;
            c = cost[u.orientare][u.i][u.j];
        } else if (u.orientare == 1 && u.j == v.j) {
            v.orientare = u.orientare;
            c = cost[u.orientare][u.i][u.j];
        } else {
            /* Pentru o intoarcere costul creste cu 1 */
            v.orientare = 1 - u.orientare;
            c = cost[u.orientare][u.i][u.j] + 1;
        }

        return {v, c};
    };

    /* Initializez costurile pentru fiecare spatiu*/
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cost[0][i][j] = 2e9;
            cost[1][i][j] = 2e9;
        }
    }

    /* Costul pentru celula initiala este 0 */
    cost[0][start.i][start.j] = 0;
    cost[1][start.i][start.j] = 0;

    int st = 2 * n * m, dr = st;

    coada[st] = {start.i, start.j, 0};
    coada[--st] = {start.i, start.j, 1};

    while (st <= dr) {
        Nod tata = coada[st++];

        /* Am ajuns la destinatie */
        if (tata == finis) {
            fout << cost[tata.orientare][tata.i][tata.j];
            break;
        }

        for (int p = 0; p < 4; p++) {
            int i = tata.i + di[p];
            int j = tata.j + dj[p];

            /* Verific daca ma aflu in limite cu indicii si 
             * daca nu este spatiu ocupat (perete)
             */
            if (good({i, j, 0})) {
                auto[fiu, costFiu] = getFiu(tata, {i, j, 0});

                if (costFiu < cost[fiu.orientare][fiu.i][fiu.j]) {
                    cost[fiu.orientare][fiu.i][fiu.j] = costFiu;
                    if (fiu.orientare == tata.orientare) {
                        coada[--st] = fiu;
                    } else {
                        coada[++dr] = fiu;
                    }
                }
            }
        }
    }

    /* Inchid fisierul de iesire */
    fout.close();

    return 0;
}
/*
 * Stefan Elena-Ioana 323CB
 */
