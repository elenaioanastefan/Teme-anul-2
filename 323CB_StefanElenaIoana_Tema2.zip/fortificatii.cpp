#include <bits/stdc++.h>
#define MAX 100005

using namespace std;

/* Deschid fisierele de intrare si de iesire */
ifstream fin("fortificatii.in");
ofstream fout("fortificatii.out");

struct Nod {
    long long cost;
    int nod;

    bool operator < (const Nod& other) const {
        return cost > other.cost;
    }
};

int n, m, k, b;
int eBarbar[MAX];
long long cost[MAX];
vector<Nod> v[MAX];
vector<long long> margine;
priority_queue<Nod> q;

int main() {
    /* Citesc datele din fisierul de intrare */
    fin >> n >> m >> k >> b;

    for (int i = 1, x; i <= b; i++) {
        fin >> x;
        eBarbar[x] = 1;
    }

    for (int i = 1, x, y; i <= m; i++) {
        long long t;
        fin >> x >> y >> t;
        v[x].push_back({t, y});
        v[y].push_back({t, x});
    }

    /* Inchid fisierul de intrare */
    fin.close();

    /* Initializez costurile */
    for (int i = 1; i <= n; i++) {
        cost[i] = 2e18;
    }

    /* Adaug in coada cu prioritati nodul sursa */
    q.push({0, 1});
    /* Costul nodului sursa este mereu 0 */
    cost[1] = 0;

    /* Folosesc algoritmul lui Dijkstra doar prin noduri in care 
     * nu se afla asezari barbare
     */ 

    while (q.size() > 0) {
        Nod tata = q.top();
        q.pop();

        for (Nod fiu : v[tata.nod]) {
            if (!eBarbar[fiu.nod]) {
                long long costFiu = tata.cost + fiu.cost;

                if (costFiu < cost[fiu.nod]) {
                    /* Actualizez costul */
                    cost[fiu.nod] = costFiu;
                    q.push({costFiu, fiu.nod});
                }
            }
        }
    }

    /* Reduc graful la un vector */
    for (int i = 1; i <= n; i++) {
        if (eBarbar[i]) {
            for (auto j : v[i]) {
                if (!eBarbar[j.nod] && cost[j.nod] < 2e18) {
                    margine.push_back(cost[j.nod] + j.cost);
                }
            }
        }
    }

    long long l = *min_element(margine.begin(), margine.end());
    long long result = l + k;

    /* Caut binar valoarea minima maxima facand maxim K incrementari */
    while (l <= result) {
        long long mid = l + (result - l) / 2;
        long long need = 0;

        for (auto it : margine) {
            if (it < mid) {
                need += mid - it;
                if (need > k) {
                    break;
                }
            }
        }

        if (need <= k) {
            l = mid + 1;
        } else {
            result = mid - 1;
        }
    }

    fout << result;

    /* Inchid fisierul de iesire */
    fout.close();

    return 0;
}
/*
 * Stefan Elena-Ioana 323CB
 */
