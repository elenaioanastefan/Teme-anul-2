#include <iostream>
#include <fstream>
using namespace std;

int n;
//Functie care calculeaza gradul unui nod p folosindu-ma de matricea de adiacenta
int degree (int p, int matrix[1000][1000]) {
    int deg = 0;
    for (int k = 1; k <= n; k++) {
	    if (matrix[p][k] == 1) {		
	        deg++; 
        }
    }
    return deg;
}

//Functie care returneaza daca se afla un subgraf complet de dim k in graful initial sau nu
bool k_Clique (int auxiliar[1][1000], int matrix[][1000], int k) {
    int size = 1;//Marimea subgrafului complet calculata la fiecare pas
    bool found1 = false;
    bool found2 = true;
    
    for (int p = 1; p <= n; p++) {//Parcurg pe rand toate nodurile grafului
        if (degree(p, matrix) >= k - 1) {/*Verific daca gradul nodului p este >= k - 1
                                          *Daca nu este >= k - 1 atunci nu poate face parte dintr-un subgraf
                                          *complet de dimensiune k
                                          */
            //Salvez nodul respectiv
            auxiliar[1][size] = p;
            for (int a = 1; a < size; a++) { 
                for (int b = a + 1; b <= size - 2; b++) {
                    /*Verific in matricea de adiacenta daca exista vreun 0 pe indicii unde ma intereseaza
                     *Daca nu exista 0 inseamna ca avem un subgraf complet
                     */
                    if (!matrix[auxiliar[1][a]][auxiliar[1][b + 1]]) {
                        found2 = false;
                    }
                }
            }
            if (found2) {
                if (size < k) {
                    //Daca size nu este inca k, atunci il cresc si continui sa caut
                    size ++; 
                }
                else if (size == k) { 
                    //Daca size este k, atunci am gasit un subgraf complet de dimensiune k
                    found1 = true;
                }
            }
        }      
    } 
    //Returnez valoarea de adevar
    return found1;
}

int main (int argc, char* argv[]) {
    //Citesc din fisierele de intrare, date in linia de comanda
    ifstream fin(argv[1]);
    
    int a[1000][1000] = {0}, matrix[1000][1000] = {0}, auxiliar[1][1000] = {0};
    int m = 0, p, q, k = 0;
    //Citesc k, n si m din fisierele de intrare
    fin >> k >> n >> m;
    //Citesc matricea de muchii a grafului din fisierele de intrare
    for (p = 1; p <= m; p++) {
        for (q = 1; q <= 2; q++) {
            fin >> a[p][q];
        }
        //Construiesc matricea de adiacenta a grafului
        matrix[a[p][1]][a[p][2]] = 1;
        matrix[a[p][2]][a[p][1]] = 1;
    } 
    
    //Returnez True sau False in functie de rezultatul functiei k_Clique
    if (k_Clique(auxiliar, matrix, k)) {
        cout << "True\n";
    }
    else {
        cout << "False\n";
    }
    
    fin.close();

    return 0;
}

/*Stefan Elena-Ioana 323CB*/