#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <netdb.h>
#include <arpa/inet.h>
#include "helpers.h"
#include "requests.h"
#include "string.h"
#include "parson.h"

#define LINE_SIZE 16
#define USER_LENGTH 64
#define COOKIE_LENGTH 512
#define DATA_LENGTH 32

int main(int argc, char *argv[]) {

    char line[LINE_SIZE];
    int socket;
    char *user, *pass, *data, *message, *ans, *token, *ckie = NULL, *auth = NULL;
    JSON_Value *js_val;
    JSON_Object *js_obj;
    JSON_Array *datas;
    char title[DATA_LENGTH];
    char author[DATA_LENGTH];
    char genre[DATA_LENGTH];
    char publisher[DATA_LENGTH];
    char page_count[DATA_LENGTH];

    while (1) {
        
        token = NULL;
        memset(line, 0, LINE_SIZE);
        fgets(line, LINE_SIZE, stdin);
        line[strlen(line) - 1] = '\0';

        if (strncmp(line, "register", 9) == 0) {
            /* This is the register command for a user */

            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }
            
            /* Read the username and password */
            printf("username=");
            user = (char *)calloc(USER_LENGTH, sizeof(char));
            scanf("%s", user);

            printf("password=");
            pass = (char *)calloc(USER_LENGTH, sizeof(char));
            scanf("%s", pass);

            /* Let's create the json */
            js_val = json_value_init_object();
            js_obj = json_value_get_object(js_val);

            /* Put data in json*/
            json_object_set_string(js_obj, "username", user);
            json_object_set_string(js_obj, "password", pass);
            data = json_serialize_to_string(js_val);
            
            /* Get the message */
            message = compute_post_request("34.241.4.235", "/api/v1/tema/auth/register", "application/json", data, NULL, 0);
            if (message == NULL) {
                printf("Can't compute the message\n");
                return -1;
            }

            send_to_server(socket, message);

            /* Get response */
            ans = receive_from_server(socket);
            
            if (ans) {
                token = strtok(ans, "\n");
            }

            while (token != NULL && token[0] != '{') {
                token = strtok(NULL, "\n");
            }

            if (token != NULL) {
                /* The username is taken, so the user can't register */
                printf("Error: The username %s is taken\n", user);
                free(user);
                free(pass);
                continue;
            } else {
                printf("200 - OK - Account created!\n");
            }

            /* Free memory */
            free(user);
            free(pass);
            json_free_serialized_string(data);
            json_value_free(js_val);

            /* Let's close connection */
            close_connection(socket);
            user = pass = NULL;

        } else if (strncmp(line, "exit", 5) == 0) {
            /* This is the exit command for a user */
            break;

        } else if (strncmp(line, "login", 6) == 0) {
            /* This is the login command for a user */

            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }

            ans = NULL;

            /* Read the username and password */
            printf("username=");
            user = (char *)calloc(USER_LENGTH, sizeof(char));
            scanf("%s", user);

            printf("password=");
            pass = (char *)calloc(USER_LENGTH, sizeof(char));
            scanf("%s", pass);

            /* Let's create the json */
            js_val = json_value_init_object();
            js_obj = json_value_get_object(js_val);

            /* Put data in json*/
            json_object_set_string(js_obj, "username", user);
            json_object_set_string(js_obj, "password", pass);
            data = json_serialize_to_string(js_val);
            
            /* Get the message */
            message = compute_post_request("34.241.4.235", "/api/v1/tema/auth/login", "application/json", data, NULL, 0);
            if (message == NULL) {
                printf("Can't compute the message\n");
                return -1;
            }

            if (!token && ckie) {
                /* Someone is already logged in */
                printf("Already logged in!\n");
                continue;
            }

            send_to_server(socket, message);
            /* Get response */
            ans = receive_from_server(socket);
            
            if (ans) {
                token = strtok(ans, "\n"); 
            }

            /* Search the cookie */
            while (token != NULL && token[0] != '{') {
                if (strncmp(token, "Set-Cookie", 10) == 0) {
                    /* Found the cookie */
                    token = strtok(token, " ");
                    ckie = calloc(COOKIE_LENGTH, sizeof(char));
                    token = strtok(NULL, " ");
                    strncpy(ckie, token, strlen(token));
                    ckie[strlen(ckie) - 1] = '\0';
                }
                token = strtok(NULL, "\n");
            }

            /* Login failed : wrong credentials */
            if (token != NULL) {
                printf("Error: No account with this username: %s or wrong password\n", user);
            }

            /* We can go forward with the login */
            if (!token && ckie) {
                printf("200 - OK - Logged in!\n");

                if (auth) {
                    free(auth);   
                }
            }

            /* Free memory */
            free(user);
            free(pass);
            json_free_serialized_string(data);
            json_value_free(js_val);

            /* Let's close connection */
            close_connection(socket);
            user = pass = NULL;

        } else if (strncmp(line, "enter_library", 14) == 0) {
            /* This is the enter_library command for a user */

            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }
            ans = NULL;

            /* Get the request */
            if (ckie) {
                send_to_server(socket, message = compute_get_request("34.241.4.235", "/api/v1/tema/library/access", ckie, NULL));
                ans = receive_from_server(socket);
            }
            
            if (ans) {
                token = strtok(ans, "\n");
            }
            while (token != NULL && token[0] != '{') {
                token = strtok(NULL, "\n");
            }
            
            if (!token) {
                /* Error message because the user is not logged in */
                printf("You need to login first!\n");
            } else {
                token = strtok(token, "\"");
                /* Get the auth string */
                for (int i = 0; i < 3; i++) {
                    token = strtok(NULL, "\"");
                }

                if (!auth) {
                    /* Alloc memory for it */
                    auth = calloc(COOKIE_LENGTH, sizeof(char));
                }

                strncpy(auth, token, strlen(token));
                /* Access to the library */ 
                printf("You have entered in the library.\n");
            }

            /* Let's close connection */
            close_connection(socket);

        } else if (strncmp(line, "get_books", 10) == 0) {
            /* This is the get_books command for a user */

            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }

            ans = NULL;
            if (auth) {
                send_to_server(socket, message = compute_get_request("34.241.4.235", "/api/v1/tema/library/books", NULL, auth));
                ans = receive_from_server(socket);
            }
            
            if (ans) {
                token = strtok(ans, "\n");
            }
            
            while (token != NULL && token[0] != '[') {
                token = strtok(NULL, "\n");
            }

            if (token == NULL) {
                /* Error message because the user doesn't have access to the library */
                printf("You need to get the access to the library first!\n");
            } else {
                js_val = json_parse_string(token);
                datas = json_value_get_array(js_val);
                if (json_array_get_count(datas) == 0) {
                    /* There are no books to show */
                    printf("No books in the library!\n");
                }

                for (int i = 0; i < json_array_get_count(datas); i++) {
                    JSON_Object *val;
                    val = json_array_get_object(datas, i);
                    /* Print data about the all the books in the library */
                    printf("id: %s\n", json_serialize_to_string_pretty(json_object_get_value(val, "id")));
                    printf("title: %s\n", json_serialize_to_string_pretty(json_object_get_value(val, "title")));
                    printf("\n");
                }

                /* Free memory */
                json_value_free(js_val);
            }

            /* Let's close connection */
            close_connection(socket);

        } else if (strncmp(line, "get_book", 9) == 0) {
            /* This is the get_book command for a user */
            
            ans = NULL;
            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }

            if (auth) {
                /* Make the path to the request */
                printf("id=");
                char *id = calloc(3, sizeof(char));
                scanf("%s", id);
                char *to_req = calloc(USER_LENGTH, sizeof(char));
                strncpy(to_req, "/api/v1/tema/library/books/", 28);
                strncat(to_req, id, strlen(id));
                send_to_server(socket, message = compute_get_request("34.241.4.235", to_req, NULL, auth));
                ans = receive_from_server(socket);
                free(id);
                free(to_req);
            }

            if (!auth) {
                /* Error message because the user doesn't have access to the library */
                printf("You need to get the access to the library first!\n");
            }
           
            if (ans) {
                token = strtok(ans, "\n");
            }
            
            while (token != NULL && token[0] != '[' && token[0] != '{') {
                token = strtok(NULL, "\n");
            }

            if (token != NULL && token[0] == '{') {
                /* Error message because the book was not found */
                printf("Error: no book with this id was found\n");

            } else if (token != NULL) {
                js_val = json_parse_string(token);
                datas = json_value_get_array(js_val);
                
                JSON_Object *val = json_array_get_object(datas, 0);
                 /* Print data about the the specific book */
                printf("title: %s\n", json_object_get_string(val, "title"));
                printf("author: %s\n", json_object_get_string(val, "author"));
                printf("genre: %s\n", json_object_get_string(val, "genre"));
                printf("publisher: %s\n", json_object_get_string(val, "publisher"));
                printf("page_count: %s\n", json_serialize_to_string_pretty(json_object_get_value(val, "page_count")));
            }

            /* Let's close connection */
            close_connection(socket);

        } else if (strncmp(line, "add_book", 9) == 0) {
            /* This is the add_book command for a user */
            
            ans = NULL;
            data = NULL;
            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }

            if (!auth) {
                /* Error message because the user doesn't have access to the library */
                printf("You need to get the access to the library first!\n");
            } else {
                /* Enter the data about the book */
                printf("title=");
                scanf("%s", title);
                printf("author=");
                scanf("%s", author);
                printf("genre=");
                scanf("%s", genre);
                printf("publisher=");
                scanf("%s", publisher);
                printf("page_count=");
                scanf("%s", page_count);

                /* Check to see if the page_count is a number */
                if (atoi(page_count) > 0) {
                    js_val = json_value_init_object();
                    js_obj = json_value_get_object(js_val);
                    json_object_set_string(js_obj, "title", title);
                    json_object_set_string(js_obj, "author", author);
                    json_object_set_string(js_obj, "genre", genre);
                    json_object_set_string(js_obj, "publisher", publisher);
                    json_object_set_number(js_obj, "page_count", atoi(page_count));
                    data = json_serialize_to_string(js_val);

                    /* Check to see if the book was added with the correct data */
                    if (strcmp(json_object_get_string(js_obj, "title"), title) != 0 && 
                        strcmp(json_object_get_string(js_obj, "author"), author) != 0 &&
                        strcmp(json_object_get_string(js_obj, "genre"), genre) != 0 &&
                        strcmp(json_object_get_string(js_obj, "publisher"), publisher) != 0) {

                        printf("The book was not added correctly!\n");
                        continue;
                    }

                    if (data) {
                        send_to_server(socket, message = compute_post_request("34.241.4.235", "/api/v1/tema/library/books", "application/json", data, NULL,auth));
                        if (receive_from_server(socket)) {
                            printf("Book added!\n");
                        }
                    }
                    /* Let's close connection */
                    close_connection(socket);
                }
                else {
                    /* Error message because the page_count is not a number */
                    printf("Page count is not correct!\n");
                }
            }
            
        } else if (strncmp(line, "delete_book", 12) == 0) {
             /* This is the delete_book command for a user */

            ans = NULL;
            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }

            if (auth) {
                /* Make the path to the request */
                printf("id=");
                char *id = calloc(3, sizeof(char));
                scanf("%s", id);
                char *to_req = calloc(USER_LENGTH, sizeof(char));
                strncpy(to_req, "/api/v1/tema/library/books/", 28);
                strncat(to_req, id, strlen(id));
                send_to_server(socket, message = compute_delete_request("34.241.4.235", to_req, NULL, auth));
                ans = receive_from_server(socket);
                free(id);
                free(to_req);
            }

            if (!auth) {
                /* Error message because the user doesn't have access to the library */
                printf("You need to get the access to the library first!\n");
                continue;
            }

            
            if (ans) {
                token = strtok(ans, "\n");
            }
            
            while (token != NULL && token[0] != '{') {
                token = strtok(NULL, "\n");
            }

            if (token != NULL) {
                /* Error message because the book was not found */
                printf("Error: no book with this id was found\n");

            } else {
                /* The book is deleted */
                printf("Book deleted!\n");
            }
            close_connection(socket);
        } else if (strncmp(line, "logout", 7) == 0) {
            /* This is the logout command for a user */
            
            ans = NULL;
            /* Let's open connection */
            socket = open_connection("34.241.4.235", 8080, AF_INET, SOCK_STREAM, 0);

            if (socket < 0) {
                printf("Can't connect to server\n");
                return -1;
            }

           if (ckie) {
                send_to_server(socket, message = compute_get_request("34.241.4.235", "/api/v1/tema/auth/logout", ckie, NULL));
                ans = receive_from_server(socket);
            }

            if (ans) {
                if (auth) {
                    free(auth);
                    auth = NULL;
                }

                if(ckie) {
                    free(ckie);
                    ckie = NULL;
                }
                
                /* The user has logged out successfully */
                printf("Logged out!\n");

            } else {
                /* Error message because the user is not logged in */
                printf("You need to login first!\n");
            }
            
            /* Let's close the connection */
            close_connection(socket);
        }
    }

    return 0;
}

/* Stefan Elena-Ioana 323CB 
 * Tema 3 Protocoale de Comunicatie - Client Web. Comunicatie cu REST API
 */
