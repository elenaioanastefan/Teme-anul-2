#include <bits/stdc++.h>
using namespace std;

/* Dimensiunile */
const int N = 1e5;
const int NR_LETTERS = 26;

/* Retine numarul de aparitii ale unei litere intr-un cuvant */
int nr_lett[N][NR_LETTERS];

/* Functie de calculare a combinatiilor de cuvinte */
int statistics(int n, string words[N]) {
    int ret = -1;
    int result;
    int sum;
    int dist[N + 1];

    /* Pentru fiecare litera din alfabet */
    for (int letter = 0; letter < NR_LETTERS; letter++) {
        for (int i = 0; i < n; i++) {
            /* Calculez numarul ei de aparitii in fiecare cuvant - dimensiunea cuvantului
             * Inmultesc cu 2, astfel ajungand sa vad in care cuvant litera e majoritara
             */
            int nr_lets = nr_lett[i][letter];
            nr_lets *= 2;
            dist[i] = nr_lets - words[i].size();
        }

        /* Sortez acest vector de aparitii */
        result = -1;
        sum = 0;
        sort(dist, dist + n);

        /* Acum implementez o metoda greedy, 
         * calculez aparitiile ei in toate cuvintele si iau maximul
         */
        for (int j = n - 1; j >= 0; j--) {
            sum += dist[j];
            if (sum > 0) {
                result = n - j;
            }
        }

        /* Aici iau maximul */
        ret = (ret > result) ? ret : result;
    }

    return ret;
}
int main() {
    int n;
    ifstream f("statistics.in");
    ofstream g("statistics.out");
    string words[N];

    /* Citesc cuvintele 
     * din fisierul de in
     */
    f >> n;
    for (int i = 0; i < n; i++) {
        string word;
        f >> word;

        /* Pun aparitiile literelor */
        words[i] = word;
        int length = word.size();
        for (int j = 0; j < length; j++)
            nr_lett[i][words[i][j] - 'a'] += 1;
    }

    /* Afisez rezultatul in fisierul de out */
    g << statistics(n, words) << '\n';
    return 0;
}
/* 
 * Stefan Elena Ioana 323CB
 */
