#include <bits/stdc++.h>
using namespace std;

/* Functia de calcul al elementului din tabela Walsh
 * Cat timp dimensiunea nu a ajuns la 1, o injumatatesc
 * Verific liniiile si coloanele
 * In cazul in care snt in bounduri, injumatatesc
 * In momentul in care ies din bound-uri, scad din linie si coloana
 * dimensiunea
 */
int walsh(int x, int y, int dim, int ret) {
    while (dim != 1) {
        dim /= 2;

        if (x <= dim && y <= dim) {
            continue;
        } else if (x <= dim && y > dim) {
            y -= dim;
        } else if (x > dim && y <= dim) {
            x -= dim;
        } else {
            x -= dim;
            y -= dim;
            ret = 1 - ret;
        }
    }
    return ret;
}

int main() {
    int n, k;
    ifstream f("walsh.in");
    ofstream g("walsh.out");
    vector<int> res;
    /* Citesc dimensiunea matricei si numarul 
     * de perechi (x, y) din fisierul de in
     */
    f >> n >> k;

    /* Citesc coordonatele din fisierul de in 
     * si in acelasi timp calculez rezultatul
     */
    for (int i = 0; i < k; i++) {
        int x, y;
        f >> x >> y;
        res.push_back(walsh(x, y, n, 0));
    }

    /* Afisez rezultatul in fisierul de out */
    for (auto elem : res) {
        g << elem << endl;
    }
    f.close();
    g.close();
    return 0;
}
/* 
 * Stefan Elena Ioana 323CB
 */
