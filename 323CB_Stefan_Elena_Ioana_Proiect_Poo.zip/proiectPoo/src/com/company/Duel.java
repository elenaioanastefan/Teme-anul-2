package com.company;

public class Duel {
}
