package com.company;

import java.io.FileWriter;
import java.io.IOException;

public class Logger {

    static FileWriter file;

    static {
        try {
            file = new FileWriter("C:\\Users\\irina\\Desktop\\proiectPoo\\lupta.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void Afisare (String s){
        System.out.println(s);
    }

    public static void AfisareText (String s, FileWriter file) throws IOException {
        file.write(s);
    }
}
