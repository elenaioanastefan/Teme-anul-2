package com.company;

public abstract class Comanda {
    public abstract void executa1(Pokemon pokemon1);
    public abstract void executa2(Pokemon pokemon1);
}

class ComandaNormalAttack extends Comanda {
    public void executa1(Pokemon pokemon1) {
        LuptaNeutrel1.atacNormal(pokemon1);
    }
    public void executa2(Pokemon pokemon1) {
        LuptaNeutrel2.atacNormal(pokemon1);
    }
}

class ComandaSpeciaLAttack extends Comanda {
    public void executa1(Pokemon pokemon1) {
        LuptaNeutrel1.atacSpecial(pokemon1);
    }
    public void executa2(Pokemon pokemon1) {
        LuptaNeutrel2.atacSpecial(pokemon1);
    }
}

class ComandaAbility1 extends Comanda {
    public void executa1(Pokemon pokemon1) {
        LuptaNeutrel1.abilitate1(pokemon1);
    }
    public void executa2(Pokemon pokemon1) {
        LuptaNeutrel2.abilitate1(pokemon1);
    }
}

class ComandaAbility2 extends Comanda {
    public void executa1(Pokemon pokemon1) {
        LuptaNeutrel1.abilitate2(pokemon1);
    }
    public void executa2(Pokemon pokemon1) {
        LuptaNeutrel2.abilitate2(pokemon1);
    }
}