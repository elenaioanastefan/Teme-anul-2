package com.company;

import java.util.*;

abstract class Pokemon {
    int HP;
    int normalAttack;
    int specialAttack;
    int normalDefense;
    int specialDefense;
    Abilities ability1;
    Abilities ability2;

    Set<Obiecte> items = new HashSet<Obiecte>();

    abstract public Set<Obiecte> getItems();

    abstract public void setItems(Set<Obiecte> items);

    abstract public String toString();

    public Pokemon withItems(List<Obiecte> items){
        this.setItems(new HashSet<>(items));
        return this;
    }

    public int getHP() {
        return HP;
    }

    public Abilities getAbility2() {
        return ability2;
    }

    public Abilities getAbility1() {
        return ability1;
    }

    public int getSpecialDefense() {
        return specialDefense;
    }

    public int getNormalDefense() {
        return normalDefense;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public int getNormalAttack() {
        return normalAttack;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }

    public void setAbility2(Abilities ability2) {
        this.ability2 = ability2;
    }

    public void setAbility1(Abilities ability1) {
        this.ability1 = ability1;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    public void setNormalDefense(int normalDefense) {
        this.normalDefense = normalDefense;
    }

    public void setSpecialAttack(int specialAttack) {
        this.specialAttack = specialAttack;
    }

    public void setNormalAttack(int normalAttack) {
        this.normalAttack = normalAttack;
    }

    public static void Initializare (Pokemon pokemon1) {
        List<Obiecte> items = convertSetToList(pokemon1.getItems());

        for (Obiecte a : items) {
            if (Objects.equals(a.toString(), ItemsFactory.TipObiecte.Scut.toString())) {
                pokemon1.setNormalDefense(pokemon1.getNormalDefense() + a.getNormalDefense());
                pokemon1.setSpecialDefense(pokemon1.getSpecialDefense() + a.getSpecialDefense());
            }
            if (Objects.equals(a.toString(), ItemsFactory.TipObiecte.Vesta.toString())) {
                pokemon1.setHP(pokemon1.getHP() +  a.getHP());
            }
            if (Objects.equals(a.toString(), ItemsFactory.TipObiecte.Sabiuta.toString())) {
                if (pokemon1.getNormalAttack() != 0) {
                    pokemon1.setNormalAttack(pokemon1.getNormalAttack() + a.getNormalAttack());
                }
            }
            if (Objects.equals(a.toString(), ItemsFactory.TipObiecte.BaghetaMagica.toString())) {
                if (pokemon1.getSpecialAttack() != 0) {
                    pokemon1.setSpecialAttack(pokemon1.getSpecialAttack() + a.getSpecialAttack());
                }
            }
            if (Objects.equals(a.toString(), ItemsFactory.TipObiecte.Vitamine.toString())) {
                pokemon1.setHP(pokemon1.getHP() + a.getHP());
                if (pokemon1.getNormalAttack() != 0) {
                    pokemon1.setNormalAttack(pokemon1.getNormalAttack() + a.getNormalAttack());
                }
                if (pokemon1.getSpecialAttack() != 0) {
                    pokemon1.setSpecialAttack(pokemon1.getSpecialAttack() + a.getSpecialAttack());
                }
            }
            if (Objects.equals(a.toString(), ItemsFactory.TipObiecte.BradDeCraciun.toString())) {
                if (pokemon1.getNormalAttack() != 0) {
                    pokemon1.setNormalAttack(pokemon1.getNormalAttack() + a.getNormalAttack());
                }
                pokemon1.setNormalDefense(pokemon1.getNormalDefense() + a.getNormalDefense());
            }
            if (Objects.equals(a.toString(), ItemsFactory.TipObiecte.Pelerina.toString())) {
                pokemon1.setSpecialDefense(pokemon1.getSpecialDefense() + a.getSpecialDefense());
            }
        }
    }

    public static void Up (Pokemon pokemon1) {
        pokemon1.setHP(pokemon1.getHP() + 1);
        if (pokemon1.getNormalAttack() != 0) {
            pokemon1.setNormalAttack(pokemon1.getNormalAttack() + 1);
        }
        if (pokemon1.getSpecialAttack() != 0) {
            pokemon1.setSpecialAttack(pokemon1.getSpecialAttack() + 1);
        }
        pokemon1.setNormalDefense(pokemon1.getNormalDefense() + 1);
        pokemon1.setSpecialDefense(pokemon1.getSpecialDefense() + 1);
    }

    public static <T> List<T> convertSetToList(Set<T> set) {
        List<T> list = new ArrayList<>(set);

        return list;
    }
}

class Neutrel1 extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Neutrel1 (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                    Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Neutrel1";
    }
}

class Neutrel2 extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Neutrel2 (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Neutrel2";
    }
}

class Pikachu extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Pikachu (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Pikachu";
    }

}

class Bulbasaur extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Bulbasaur (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Bulbasaur";
    }
}

class Charmander extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Charmander (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Charmander";
    }
}

class Squirtle extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Squirtle (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Squirtle";
    }


}

class Snorlax extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Snorlax (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Snorlax";
    }
}

class Vulpix extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Vulpix (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Vulpix";
    }
}

class Eevee extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Eevee (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Eevee";
    }
}

class Jigglypuff extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Jigglypuff (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Jigglypuff";
    }
}

class Meowth extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Meowth (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Meowth";
    }
}

class Psyduck extends Pokemon {

    Set<Obiecte> items = new HashSet<Obiecte>();

    public Psyduck (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense,
                     Abilities ability1,  Abilities ability2) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
        this.ability1 = ability1;
        this.ability2 = ability2;
    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String toString () {
        return "Psyduck";
    }
}

class PokemonFactory {
    private static PokemonFactory instance;

    public static enum TipPokemon {
        Neutrel1, Neutrel2, Pikachu, Bulbasaur, Charmander, Squirtle, Snorlax, Vulpix,
        Eevee, Jigglypuff, Meowth, Psyduck
    }

    public Pokemon creeazaPokemon(TipPokemon p) {
        switch (p) {
            case Neutrel1 :
                return new Neutrel1(10,3,0,1,1,null,null);
            case Neutrel2 :
                return new Neutrel2(20,4,0,1,1,null,null);
            case Pikachu :
                return new Pikachu(35,0,4,2,3,
                        new Abilities(6,"No","No",4),
                        new Abilities(4,"Yes","Yes",5));
            case Bulbasaur :
                return new Bulbasaur(42,0,5,3,1,
                        new Abilities(6,"No","No",4),
                        new Abilities(5,"No","No",3));
            case Charmander :
                return new Charmander(50,4,0,3,2,
                        new Abilities(4,"Yes","No",4),
                        new Abilities(7,"No","No",6));
            case Squirtle :
                return new Squirtle(60,0,3,5,5,
                        new Abilities(4,"No","No",3),
                        new Abilities(2,"Yes","No",2));
            case Snorlax :
                return new Snorlax(62,3,0,6,4,
                        new Abilities(4,"Yes","No",5),
                        new Abilities(0,"No","Yes",5));
            case Vulpix :
                return new Vulpix(36,5,0,2,4,
                        new Abilities(8,"Yes","No",6),
                        new Abilities(2,"No","Yes",7));
            case Eevee :
                return new Eevee(39,0,4,3,3,
                        new Abilities(5,"No","No",3),
                        new Abilities(3,"Yes","No",3));
            case Jigglypuff :
                return new Jigglypuff(34,4,0,2,3,
                        new Abilities(4,"Yes","No",4),
                        new Abilities(3,"Yes","No",4));
            case Meowth :
                return new Meowth(41,3,0,4,2,
                        new Abilities(5,"No","Yes",4),
                        new Abilities(1,"No","Yes",3));
            case Psyduck :
                return new Psyduck(43,3,0,3,3,
                        new Abilities(2,"No","No",4),
                        new Abilities(2,"Yes","No",5));

        }
        throw new IllegalArgumentException("Tipul de pokemon " + p + " nu este cunoscut.");
    }

}

