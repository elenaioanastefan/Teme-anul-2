package com.company;

abstract class Obiecte {
    int HP;
    int normalAttack;
    int specialAttack;
    int normalDefense;
    int specialDefense;

    abstract public String toString();

    public int getSpecialDefense() {
        return specialDefense;
    }

    public void setSpecialDefense(int specialDefense) {
        this.specialDefense = specialDefense;
    }

    public int getNormalDefense() {
        return normalDefense;
    }

    public void setNormalDefense(int normalDefense) {
        this.normalDefense = normalDefense;
    }

    public int getSpecialAttack() {
        return specialAttack;
    }

    public void setSpecialAttack(int specialAttack) {
        this.specialAttack = specialAttack;
    }

    public int getNormalAttack() {
        return normalAttack;
    }

    public void setNormalAttack(int normalAttack) {
        this.normalAttack = normalAttack;
    }

    public int getHP() {
        return HP;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }
}

class Scut extends Obiecte {
    public Scut (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
    }

    public String toString () {
        return "Scut";
    }
}

class Vesta extends Obiecte {
    public Vesta (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
    }

    public String toString () {
        return "Vesta";
    }
}

class Sabiuta extends Obiecte {
    public Sabiuta (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
    }

    public String toString () {
        return "Sabiuta";
    }
}

class BaghetaMagica extends Obiecte {
    public BaghetaMagica (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
    }

    public String toString () {
        return "BaghetaMagica";
    }
}

class Vitamine extends Obiecte {
    public Vitamine (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
    }

    public String toString () {
        return "Vitamine";
    }
}

class BradDeCraciun extends Obiecte {
    public BradDeCraciun (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
    }

    public String toString () {
        return "BradDeCraciun";
    }
}

class Pelerina extends Obiecte {
    public Pelerina (int HP, int normalAttack, int specialAttack, int normalDefense, int specialDefense) {
        this.HP = HP;
        this.normalAttack = normalAttack;
        this.specialAttack = specialAttack;
        this.normalDefense = normalDefense;
        this.specialDefense = specialDefense;
    }

    public String toString () {
        return "Pelerina";
    }
}

class ItemsFactory {

    public static enum TipObiecte {
        Scut, Vesta, Sabiuta, BaghetaMagica, Vitamine, BradDeCraciun, Pelerina
    }

    public Obiecte creeazaObiecte(TipObiecte p) {
        switch (p) {
            case Scut:
                return new Scut(0, 0, 0, 2, 2);
            case Vesta:
                return new Vesta(10, 0, 0, 0, 0);
            case Sabiuta:
                return new Sabiuta(0, 3, 0, 0, 0);
            case BaghetaMagica:
                return new BaghetaMagica(0, 0, 3, 0, 0);
            case Vitamine:
                return new Vitamine(2, 2, 2, 0, 0);
            case BradDeCraciun:
                return new BradDeCraciun(0, 3, 0, 1, 0);
            case Pelerina:
                return new Pelerina(0, 0, 0, 0, 3);

        }
        throw new IllegalArgumentException("Tipul de obiect " + p + " nu este cunoscut.");
    }
}
