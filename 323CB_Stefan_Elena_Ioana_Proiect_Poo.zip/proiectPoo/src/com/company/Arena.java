package com.company;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class Arena {

    private static Random rand = new Random();
    private static int upperbound = 3;
    static int battleNumber = rand.nextInt(upperbound);
    static List<Antrenor> antrenori;

    static {
        try {
            antrenori = Antrenor.Instanta("C:\\Users\\irina\\Desktop\\proiectPoo\\teste\\test1.in");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static <T> List<T> convertSetToList(Set<T> set) {
        List<T> list = new ArrayList<>(set);

        return list;
    }

    public static void PickBattle(int battleNumber, Pokemon pokemon1, int HP) {

            if (battleNumber == 0) {
                Logger.Afisare("Lupta intre Neutrel1 si " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                        "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                        pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                        pokemon1.getSpecialDefense() + "\n");

                try {
                    Logger.AfisareText("Lupta intre Neutrel1 si " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                            "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                            pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                            pokemon1.getSpecialDefense() + "\n\n", Logger.file);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                int number;
                boolean a;

                do {
                    number = rand.nextInt(4);
                    a = LuptaNeutrel1.LuptaCuNeutrel1(antrenori.get(0), pokemon1, number);
                } while (a);

                if (pokemon1.getHP() > 0) {
                    pokemon1.setHP(HP);
                    Pokemon.Up(pokemon1);

                    Logger.Afisare("\nCastigatorul este : " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                            "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                            pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                            pokemon1.getSpecialDefense() + "\n");

                    try {
                        Logger.AfisareText("\nCastigatorul este : " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                                "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                                pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                                pokemon1.getSpecialDefense() + "\n\n", Logger.file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } else {
                    Logger.Afisare("\nCastigatorul este : Neutrel1\n");

                    try {
                        Logger.AfisareText("\nCastigatorul este : Neutrel1\n\n", Logger.file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            if (battleNumber == 1) {

                Logger.Afisare("Lupta intre Neutrel2 si " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                        "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                        pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                        pokemon1.getSpecialDefense() + "\n");

                try {
                    Logger.AfisareText("Lupta intre Neutrel2 si " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                            "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                            pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                            pokemon1.getSpecialDefense() + "\n\n", Logger.file);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                int number;
                boolean a;

                do {
                    number = rand.nextInt(4);
                    a = LuptaNeutrel2.LuptaCuNeutrel2(antrenori.get(0), pokemon1, number);
                } while (a);

                if (pokemon1.getHP() > 0) {
                    pokemon1.setHP(HP);
                    Pokemon.Up(pokemon1);

                    Logger.Afisare("\nCastigatorul este : " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                            "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                            pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                            pokemon1.getSpecialDefense() + "\n");

                    try {
                        Logger.AfisareText("\nCastigatorul este : " + pokemon1 + "\nCaracteristici" + "\nHP : " + pokemon1.getHP() +
                                "\nNormal attack : " + pokemon1.getNormalAttack() + "\nSpecial attack : " +
                                pokemon1.getSpecialAttack() + "\nNormal defense : " + pokemon1.getNormalDefense() + "\nSpecial defense : " +
                                pokemon1.getSpecialDefense() + "\n\n", Logger.file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    Logger.Afisare("\nCastigatorul este : Neutrel2\n");

                    try {
                        Logger.AfisareText("\nCastigatorul este : Neutrel2\n\n", Logger.file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            if (battleNumber == 2) {
                //duel intre antrenori
                //cand este ales duelul, aventura se termina
            }
        }

    public static void main(String[] args) throws IOException {

        Pokemon pokemon1 = convertSetToList(antrenori.get(0).getPokemons()).get(0);
        Pokemon pokemon2 = convertSetToList(antrenori.get(0).getPokemons()).get(1);
        Pokemon pokemon3 = convertSetToList(antrenori.get(0).getPokemons()).get(2);
        Pokemon pokemon4 = convertSetToList(antrenori.get(1).getPokemons()).get(0);
        Pokemon pokemon5 = convertSetToList(antrenori.get(1).getPokemons()).get(1);
        Pokemon pokemon6 = convertSetToList(antrenori.get(1).getPokemons()).get(2);

        Pokemon.Initializare(pokemon1);
        Pokemon.Initializare(pokemon2);
        Pokemon.Initializare(pokemon3);
        Pokemon.Initializare(pokemon4);
        Pokemon.Initializare(pokemon5);
        Pokemon.Initializare(pokemon6);

        int auxHP1 = pokemon1.getHP();
        int auxHP2 = pokemon2.getHP();
        int auxHP3 = pokemon3.getHP();
        int auxHP4 = pokemon4.getHP();
        int auxHP5 = pokemon5.getHP();
        int auxHP6 = pokemon6.getHP();

        Logger.Afisare("Evenimentul a inceput\n");

        Logger.AfisareText("Evenimentul a inceput\n\n", Logger.file);

        Arena.PickBattle(battleNumber, pokemon1, auxHP1);
        Arena.PickBattle(battleNumber, pokemon4, auxHP4);

        //lupte cu Neutrel1 sau Neutrel2 pana cand este ales duelul
        if (battleNumber != 2) {
            battleNumber = rand.nextInt(upperbound);
            Arena.PickBattle(battleNumber, pokemon2, auxHP2);
            Arena.PickBattle(battleNumber, pokemon5, auxHP5);
        }

        if (battleNumber != 2) {
            battleNumber = rand.nextInt(upperbound);
            Arena.PickBattle(battleNumber, pokemon3, auxHP3);
            Arena.PickBattle(battleNumber, pokemon6, auxHP6);
        }
        Logger.file.close();

    }
}
