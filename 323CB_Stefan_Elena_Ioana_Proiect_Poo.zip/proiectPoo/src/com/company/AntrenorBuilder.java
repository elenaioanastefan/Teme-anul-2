package com.company;

import java.util.*;

public class AntrenorBuilder {
    private final Antrenor antrenor = new Antrenor();

    public AntrenorBuilder withName(String name) {
        antrenor.setName(name);
        return this;
    }

    public AntrenorBuilder withAge(int age) {
        antrenor.setAge(age);
        return this;
    }

    public AntrenorBuilder addPokemon(List<Pokemon> pokemon) {
        antrenor.getPokemons().addAll(new HashSet<>(pokemon));
        return this;
    }

    public AntrenorBuilder addItem(List<Obiecte> item){
        antrenor.getItems().addAll(new HashSet<>(item));
        return this;
    }

    public Antrenor build(){
        return antrenor;
    }

}
