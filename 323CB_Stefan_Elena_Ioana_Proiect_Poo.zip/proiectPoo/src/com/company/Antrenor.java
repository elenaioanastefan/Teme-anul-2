package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Antrenor {

    private static List<Antrenor> antrenori;
    String name;
    int age;
    Set<Pokemon> pokemons = new HashSet<Pokemon>();
    Set<Obiecte> items = new HashSet<Obiecte>();

    public static List<Antrenor> Instanta (String path) throws FileNotFoundException {
        if (antrenori == null) {
            antrenori = readData(path);
        }
        return antrenori;
    }

    private static List<Antrenor> readData (String path) throws FileNotFoundException {

        String name;
        int age;
        String[] pokemonNames;
        String[] pokemonItems;

        PokemonFactory f = new PokemonFactory();
        ItemsFactory f1 = new ItemsFactory();

        List<Pokemon> pokemons = new ArrayList<Pokemon>();
        List<Obiecte> items = new ArrayList<Obiecte>();
        List <Antrenor> antrenori = new ArrayList<Antrenor>();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String st;
            br.readLine();

            while ((st = br.readLine()) != null) {
                String[] split = st.split("###");

                name = split[0];

                String ageS = split[1];
                age = Integer.parseInt(ageS);

                String aux = split[2];
                pokemonNames = aux.split(";");

                String aux2 = split[3];
                pokemonItems = aux2.split(";");

                for (String names : pokemonNames) {
                    for (PokemonFactory.TipPokemon tip : PokemonFactory.TipPokemon.values()) {
                        if (Objects.equals(String.valueOf(tip), names)) {
                            Pokemon a = f.creeazaPokemon(PokemonFactory.TipPokemon.valueOf(names));
                            pokemons.add(a);
                        }
                    }
                }

                for (String item : pokemonItems) {
                    for (ItemsFactory.TipObiecte tip : ItemsFactory.TipObiecte.values()) {
                        if (Objects.equals(String.valueOf(tip), item)) {
                            Obiecte b = f1.creeazaObiecte(ItemsFactory.TipObiecte.valueOf(item));
                            items.add(b);
                        }
                    }
                }

                for (Pokemon a : pokemons) {
                    a.withItems(items);
                }

                Antrenor newAntrenor = new AntrenorBuilder()
                            .withName(name)
                            .withAge(age)
                            .addPokemon(pokemons)
                            .addItem(items)
                            .build();

                antrenori.add(newAntrenor);

                pokemons.clear();
                items.clear();

            }

        return antrenori;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Antrenor() {

    }

    public Set<Obiecte> getItems() {
        return items;
    }

    public void setItems(Set<Obiecte> items) {
        this.items = items;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Set<Pokemon> getPokemons() {
        return pokemons;
    }

    public void setPokemons(Set<Pokemon> pokemons) {
        this.pokemons = pokemons;
    }

    @Override
    public String toString () {
      return "Nume " + name + ", varsta " + age + ", pokemoni " + pokemons.toString() + items.toString();

    }


}
