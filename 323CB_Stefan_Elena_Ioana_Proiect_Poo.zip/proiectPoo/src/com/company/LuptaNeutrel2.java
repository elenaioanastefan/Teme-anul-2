package com.company;

import java.io.IOException;
import java.util.*;

public class LuptaNeutrel2 {

    static PokemonFactory f = new PokemonFactory();
    static Pokemon Neutrel2 = f.creeazaPokemon(PokemonFactory.TipPokemon.Neutrel2);

    public static void atacNormal (Pokemon pokemon1) {

        Logger.Afisare("\nExecuta atac normal\n");

        try {
            Logger.AfisareText("\nExecuta atac normal\n\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (pokemon1.getNormalAttack() > Neutrel2.getNormalAttack()) {
            Neutrel2.setHP(Neutrel2.getHP() - (pokemon1.getNormalAttack() - Neutrel2.getNormalDefense()));
        }
        else if (pokemon1.getNormalAttack() < Neutrel2.getNormalAttack()) {
            //daca defense-ul pokemon-ului este mai mare, atunci nu este produs niciun damage la HP
            if (pokemon1.getNormalDefense() > Neutrel2.getNormalAttack()) {
                pokemon1.setHP(pokemon1.getHP());
            } else {
                pokemon1.setHP(pokemon1.getHP() - (Neutrel2.getNormalAttack() - pokemon1.getNormalDefense()));
            }
        }
        else if (pokemon1.getNormalAttack() == Neutrel2.getNormalAttack()) {
            pokemon1.setHP(pokemon1.getHP());
            Neutrel2.setHP(Neutrel2.getHP());
        }

        Logger.Afisare("HP Neutrel2 : " + Neutrel2.getHP());
        Logger.Afisare("HP " + pokemon1 + " : " + pokemon1.getHP());

        try {
            Logger.AfisareText("HP Neutrel2 : " + Neutrel2.getHP() + "\n", Logger.file);
            Logger.AfisareText( "HP " + pokemon1 + " : " + pokemon1.getHP() + "\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void atacSpecial (Pokemon pokemon1) {

        Logger.Afisare("\nExecuta atac special\n");

        try {
            Logger.AfisareText("\nExecuta atac special\n\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (pokemon1.getSpecialAttack() > Neutrel2.getSpecialAttack()) {
            Neutrel2.setHP(Neutrel2.getHP() - (pokemon1.getSpecialAttack() - Neutrel2.getSpecialDefense()));
        }
        else if (pokemon1.getSpecialAttack() < Neutrel2.getSpecialAttack()) {
            if (pokemon1.getSpecialDefense() > Neutrel2.getSpecialAttack()) {
                pokemon1.setHP(pokemon1.getHP());
            } else {
                pokemon1.setHP(pokemon1.getHP() - (Neutrel2.getSpecialAttack() - pokemon1.getSpecialDefense()));
            }
        }
        else if (pokemon1.getSpecialAttack() == Neutrel2.getSpecialAttack()) {
            pokemon1.setHP(pokemon1.getHP());
            Neutrel2.setHP(Neutrel2.getHP());
        }

        Logger.Afisare("HP Neutrel2 : " + Neutrel2.getHP());
        Logger.Afisare("HP " + pokemon1 + " : " + pokemon1.getHP());

        try {
            Logger.AfisareText("HP Neutrel2 : " + Neutrel2.getHP() + "\n", Logger.file);
            Logger.AfisareText(  "HP " + pokemon1 + " : " + pokemon1.getHP() + "\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void abilitate1 (Pokemon pokemon1) {

        Logger.Afisare("\nExecuta abilitate 1\n");

        try {
            Logger.AfisareText("\nExecuta abilitate 1\n\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (Objects.equals(pokemon1.getAbility1().getDodge(), "Yes")) {
            pokemon1.setHP(pokemon1.getHP());
        }
        else if (Objects.equals(pokemon1.getAbility1().getDodge(), "No") &&
                Objects.equals(pokemon1.getAbility1().getStun(), "No")) {
            if (Neutrel2.getNormalAttack() != 0) {
                if (pokemon1.getNormalDefense() > Neutrel2.getNormalAttack()) {
                    pokemon1.setHP(pokemon1.getHP());
                } else {
                    pokemon1.setHP(pokemon1.getHP() - (Neutrel2.getNormalAttack() - pokemon1.getNormalDefense()));
                }
                Neutrel2.setHP(Neutrel2.getHP() - pokemon1.getAbility1().getDamage());
            }
            else if (Neutrel2.getSpecialAttack() != 0) {
                if (pokemon1.getSpecialDefense() > Neutrel2.getSpecialAttack()) {
                    pokemon1.setHP(pokemon1.getHP());
                } else {
                    pokemon1.setHP(pokemon1.getHP() - (Neutrel2.getSpecialAttack() - pokemon1.getSpecialDefense()));
                }
                Neutrel2.setHP(Neutrel2.getHP() - pokemon1.getAbility1().getDamage());
            }
        }
        if (Objects.equals(pokemon1.getAbility1().getStun(), "Yes")) {
            //Neutrel 1 nu mai ataca,este atacat
            Neutrel2.setHP(Neutrel2.getHP() - pokemon1.getAbility1().getDamage());
        }

        Logger.Afisare("HP Neutrel2 : " + Neutrel2.getHP());
        Logger.Afisare("HP " + pokemon1 + " : " + pokemon1.getHP());

        try {
            Logger.AfisareText("HP Neutrel2 : " + Neutrel2.getHP() + "\n", Logger.file);
            Logger.AfisareText("HP " + pokemon1 + " : " + pokemon1.getHP() + "\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void abilitate2 (Pokemon pokemon1) {

        Logger.Afisare("\nExecuta abilitate 2\n");

        try {
            Logger.AfisareText("\nExecuta abilitate 2\n\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (Objects.equals(pokemon1.getAbility2().getDodge(), "Yes")) {
            pokemon1.setHP(pokemon1.getHP());
        }
        else if (Objects.equals(pokemon1.getAbility2().getDodge(), "No") &&
                Objects.equals(pokemon1.getAbility2().getStun(), "No")) {
            if (Neutrel2.getNormalAttack() != 0) {
                if (pokemon1.getNormalDefense() > Neutrel2.getNormalAttack()) {
                    pokemon1.setHP(pokemon1.getHP());
                } else {
                    pokemon1.setHP(pokemon1.getHP() - (Neutrel2.getNormalAttack() - pokemon1.getNormalDefense()));
                }
                Neutrel2.setHP(Neutrel2.getHP() - pokemon1.getAbility2().getDamage());
            }
            else if (Neutrel2.getSpecialAttack() != 0) {
                if (pokemon1.getSpecialDefense() > Neutrel2.getSpecialAttack()) {
                    pokemon1.setHP(pokemon1.getHP());
                } else {
                    pokemon1.setHP(pokemon1.getHP() - (Neutrel2.getSpecialAttack() - pokemon1.getSpecialDefense()));
                }
                Neutrel2.setHP(Neutrel2.getHP() - pokemon1.getAbility2().getDamage());
            }
        }
        if (Objects.equals(pokemon1.getAbility2().getStun(), "Yes")) {
            //Neutrel2 nu mai ataca,este atacat
            Neutrel2.setHP(Neutrel2.getHP() - pokemon1.getAbility2().getDamage());
        }

        Logger.Afisare("HP Neutrel2 : " + Neutrel2.getHP());
        Logger.Afisare("HP " + pokemon1 + " : " + pokemon1.getHP());

        try {
            Logger.AfisareText("HP Neutrel2 : " + Neutrel2.getHP() + "\n", Logger.file);
            Logger.AfisareText("HP " + pokemon1 + " : " + pokemon1.getHP() + "\n", Logger.file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void chooseAttack(Pokemon pokemon1, int attackNumber1) {
        if (attackNumber1 == 0) {
            //atac normal
            ComandaNormalAttack c = new ComandaNormalAttack();
            c.executa2(pokemon1);
        }

        if (attackNumber1 == 1) {
            //atac special
            ComandaSpeciaLAttack c = new ComandaSpeciaLAttack();
            c.executa2(pokemon1);
        }

        if (attackNumber1 == 2) {
            //abilitate1
            ComandaAbility1 c = new ComandaAbility1();
            c.executa2(pokemon1);
        }

        if (attackNumber1 == 3) {
            //abilitate2
            ComandaAbility2 c = new ComandaAbility2();
            c.executa2(pokemon1);
        }
    }

    public static boolean LuptaCuNeutrel2(Antrenor antrenor, Pokemon pokemon1, int attackNumber1) {
        boolean a = true;

        LuptaNeutrel2.chooseAttack(pokemon1, attackNumber1);

        if (pokemon1.getHP() > 0 && Neutrel2.getHP() > 0) {
            a = true;
        }
        if (pokemon1.getHP() <= 0 || Neutrel2.getHP() <= 0) {
            Neutrel2.setHP(20);
            a = false;
        }

        return a;
    }
}
