
-- =============== DO NOT MODIFY ===================

{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE FlexibleInstances #-}

-- ==================================================

module Tasks where

import Dataset
import Data.List
import Text.Printf
import Data.Array

import Common

type CSV = String
type Value = String
type Row = [Value]
type Table = [Row]
type ColumnName = String

-- Prerequisities
split_by :: Char -> String -> [String]
split_by x = foldr op [""]
  where op char acc
            | char == x = "":acc
            | otherwise = (char:head(acc)):tail(acc)

read_csv :: CSV -> Table
read_csv = (map (split_by ',')) . (split_by '\n')

write_csv :: Table -> CSV
write_csv = (foldr (++) []).
            (intersperse "\n").
            (map (foldr (++) [])).
            (map (intersperse ","))


{-
    TASK SET 1
-}


-- Task 1

-- Functie care imi transforma un rand in tuplu (String, [Float])
tuplify :: Row -> (String, [Float])
tuplify [] = ("", [])
tuplify [a] = (a,[])
tuplify [a,a1] = (a,(read a1):[])
tuplify [a,a1,a2,a3,a4,a5,a6,a7,a8] = (a, (read a1):(read a2):(read a3):(read a4):(read a5):(read a6):(read a7):(read a8):[])

-- Functie care aplica functia tuplify pe toata tabela
tuplify_f :: Table -> [(String, [Float])] 
tuplify_f =  map (tuplify)

-- Functie care extrage al doilea element dintr-un tuplu
second :: (String, [Float]) -> [Float]
second (_,[]) = []
second (_,x) = x

second_f :: [(String, [Float])] -> [[Float]]
second_f = map (second)

-- Functie care extrage primul element dintr-un tuplu
first :: (String, [Float]) -> String
first ([],_) = []
first (x,_) = x

first_f :: [(String, [Float])] -> [String]
first_f = map (first)

-- Functie care calculeaza media aritmetica a unei liste de numere
average :: [Float] -> Float
average = (/8).(sum)

average_f :: [[Float]] -> [Float]
average_f = map (average)

-- Functie care creeaza un tuplu
tuplify_again :: String -> Float -> (String, Float)
tuplify_again a b = (a, b)

-- Functie care tranforma un tuplu intr-un row - o lista
toRow :: (String, Float) -> Row
toRow (a, b) = a:(printf "%.2f" b):[]

toTable :: [(String, Float)] -> Table
toTable = map (toRow)

compute_average_steps :: Table -> Table
compute_average_steps m = ["Name","Average Number of Steps"]:(toTable (zip (first_f (tuplify_f (tail m))) (average_f (second_f (tuplify_f (tail m))))))

-- Task 2

-- Functie care calculeaza suma elementelor unei liste, pentru fiecare lista
sum_f :: [[Float]] -> [Float]
sum_f = map (sum)

-- Functie care verifica daca se poate aplica head pe o lista
check :: Table -> Int
check m = if (null (sum_f (second_f (tuplify_f m)))) == True then 0
    else round (head (sum_f (second_f (tuplify_f m))))

-- Functie care verifica daca se poate aplica tail pe o lista
check1 :: Table -> Table
check1 m = if ((null (first_f (tuplify_f m)) == True) || (null (sum_f (second_f (tuplify_f m))) == True)) then [[]]
  else toTable (zip (tail (first_f (tuplify_f m))) (tail (sum_f (second_f (tuplify_f m)))))

-- Number of people who have achieved their goal:
get_passed_people_num :: Table -> Int
get_passed_people_num [[]] = 0
get_passed_people_num m = if (check m) >= 1000 then 
  1 + (get_passed_people_num (check1 m))
    else (get_passed_people_num (check1 m)) 

-- Functie care calculeaza numarul de oameni din tabela
get_people_num :: Table -> Int
get_people_num [[]] = 0
get_people_num m = if (check m) >= 0 then 
  1 + (get_people_num (check1 m))
    else (get_people_num (check1 m)) 

-- Functie care realizeaza impartirea a doua numere Int => Float
divide :: Int -> Int -> Float
divide a b = (fromIntegral a) / (fromIntegral b)

-- Percentage of people who have achieved their goal:
get_passed_people_percentage :: Table -> Float
get_passed_people_percentage m = divide (get_passed_people_num m) (get_people_num (tail m))

-- Average number of daily steps
get_steps_avg :: Table -> Float
get_steps_avg m = (fromIntegral (round (sum (sum_f (second_f (tuplify_f (tail m))))))) / (fromIntegral (length (sum_f (second_f (tuplify_f (tail m))))))

-- Task 3

-- Functie care calculeaza suma de pasi pe ore => O lista care contine 8 elemente
avg_sum :: Table -> [Float]
avg_sum m = foldr (zipWith (+)) [0,0,0,0,0,0,0,0] (second_f (tuplify_f (tail m)))

-- Functie care calculeaza numarul de oameni din tabela (returneaza Float)
get_num :: Table -> Float
get_num [[]] = 0
get_num m = if (check m) >= 0 then 
  1 + (get_num (check1 m))
    else (get_num (check1 m)) 

-- Functie care calculeaza media aritmetica a numarului de pasi pe ore
avg :: [Float] -> [Float]
avg = map (/get_num (tail (tail Dataset.eight_hours)))

-- Functie care converteste din lista de Float in lista de String
convert :: [Float] -> [Value]
convert = map (printf "%.2f")

get_avg_steps_per_h :: Table -> Table
get_avg_steps_per_h m = ["H10","H11","H12","H13","H14","H15","H16","H17"]:[(convert (avg (avg_sum m)))]

-- Task 4

-- Functie care tranforma un rand intr-un tuplu
tuplify_t4 :: Row -> (String, Integer, Float, Integer, Integer, Integer)
tuplify_t4 [] = ("", 0, 0.0, 0, 0, 0)
tuplify_t4 [a1,a2,a3,a4,a5,a6] = (a1,(read a2),(read a3),(read a4),(read a5),(read a6))

tuplify_t4_f :: Table -> [(String, Integer, Float, Integer, Integer, Integer)] 
tuplify_t4_f =  map (tuplify_t4)

-- Functie care extrage al patrulea element dintr-un tuplu
fourth :: (String, Integer, Float, Integer, Integer, Integer) -> Integer
fourth (_,_,_,0,_,_) = 0
fourth (_,_,_,x,_,_) = x

fourth_f :: [(String, Integer, Float, Integer, Integer, Integer)] -> [Integer]
fourth_f = map (fourth)

-- Functie care extrage al cincilea element dintr-un tuplu
fifth :: (String, Integer, Float, Integer, Integer, Integer) -> Integer
fifth (_,_,_,_,0,_) = 0
fifth (_,_,_,_,x,_) = x

fifth_f :: [(String, Integer, Float, Integer, Integer, Integer)] -> [Integer]
fifth_f = map (fifth)

-- Functie care extrage al saselea element dintr-un tuplu
sixth :: (String, Integer, Float, Integer, Integer, Integer) -> Integer
sixth (_,_,_,_,_,0) = 0
sixth (_,_,_,_,_,x) = x

sixth_f :: [(String, Integer, Float, Integer, Integer, Integer)] -> [Integer]
sixth_f = map (sixth)

-- 3 functii care verifica cate persoane au range-ul, pe rand, [0,50), [50,100), [100,500)

range1 :: [Integer] -> Integer
range1 [] = 0
range1 (x:xs) = if (x >= 0) && (x < 50) then 1 + (range1 xs)
    else (range1 xs)
-- range1 (fourth_f (tuplify_1_f (tail m))) - VAM
-- range1 (fifth_f (tuplify_1_f (tail m))) - FAM
-- range1 (sixth_f (tuplify_1_f (tail m))) - LAM
range2 :: [Integer] -> Integer
range2 [] = 0
range2 (x:xs) = if (x >= 50) && (x < 100) then 1 + (range2 xs)
    else (range2 xs)
-- range2 (fourth_f (tuplify_1_f (tail m))) - VAM
-- range2 (fifth_f (tuplify_1_f (tail m))) - FAM
-- range2 (sixth_f (tuplify_1_f (tail m))) - LAM
range3 :: [Integer] -> Integer
range3 [] = 0
range3 (x:xs) = if (x >= 100) && (x < 500) then 1 + (range3 xs)
    else (range3 xs)
-- range3 (fourth_f (tuplify_1_f (tail m))) - VAM
-- range3 (fifth_f (tuplify_1_f (tail m))) - FAM
-- range3 (sixth_f (tuplify_1_f (tail m))) - LAM

get_activ_summary :: Table -> Table
get_activ_summary m = ["column","range1","range2","range3"]:
    ["VeryActiveMinutes",(printf "%d" (range1 (fourth_f (tuplify_t4_f (tail m))))),(printf "%d" (range2 (fourth_f (tuplify_t4_f (tail m))))),(printf "%d" (range3 (fourth_f (tuplify_t4_f (tail m)))))]:
    ["FairlyActiveMinutes",printf "%d" (range1 (fifth_f (tuplify_t4_f (tail m)))),printf "%d" (range2 (fifth_f (tuplify_t4_f (tail m)))),printf "%d" (range3 (fifth_f (tuplify_t4_f (tail m))))]:
    ["LightlyActiveMinutes",printf "%d" (range1 (sixth_f (tuplify_t4_f (tail m)))),printf "%d" (range2 (sixth_f (tuplify_t4_f (tail m)))),printf "%d" (range3 (sixth_f (tuplify_t4_f (tail m))))]:
    []

-- Task 5

-- Functie care tranforma un tuplu intr-un Row - lista
toRow_t5 :: (String, Integer, Float, Integer, Integer, Integer) -> Row
toRow_t5 (a,b,_,_,_,_) = a:(printf "%d" b):[]

toTable_t5 :: [(String, Integer, Float, Integer, Integer, Integer)] -> Table
toTable_t5 = map (toRow_t5)

get_ranking :: Table -> Table
get_ranking m = ["Name","Total Steps"]:(toTable_t5 (sortBy (\(_,a,_,_,_,_) (_,b,_,_,_,_) -> compare a b) (sortBy (\(a,_,_,_,_,_) (b,_,_,_,_,_) -> compare a b) (tuplify_t4_f (tail m)))))

-- Task 6

-- Functie care tranforma un rand intr-un tuplu
tuplify_t6 :: Row -> (String, [Float], [Float])
tuplify_t6 [] = ("", [], [])
tuplify_t6 [a] = (a, [], [])
tuplify_t6 [a, a1] = (a, (read a1):[], [])
tuplify_t6 [a, a1, a2] = (a, (read a1):[], (read a2):[])
tuplify_t6 [a,a1,a2,a3,a4,a5,a6,a7,a8] = (a, (read a1):(read a2):(read a3):(read a4):[], (read a5):(read a6):(read a7):(read a8):[])

tuplify_t6_f :: Table -> [(String, [Float], [Float])] 
tuplify_t6_f =  map (tuplify_t6)

-- Functie care extrage al treilea element dintr-un tuplu
third_t6 :: (String, [Float], [Float]) -> [Float]
third_t6 (_, _, []) = []
third_t6 (_, _, x) = x

third_t6_f :: [(String, [Float], [Float])] -> [[Float]]
third_t6_f = map (third_t6)

-- Functie care extrage al doilea element dintr-un tuplu
second_t6 :: (String, [Float], [Float]) -> [Float]
second_t6 (_, [], _) = []
second_t6 (_, x, _) = x

second_t6_f :: [(String, [Float], [Float])] -> [[Float]]
second_t6_f = map (second_t6)

-- Functie care extrage primul element dintr-un tuplu
first_t6 :: (String, [Float], [Float]) -> String
first_t6 ([], _, _) = []
first_t6 (x, _, _) = x

first_t6_f :: [(String, [Float], [Float])] -> [String]
first_t6_f = map (first_t6)

-- Functie care calculeaza media aritmetica a numarului de pasi pentru 4 ore
average_t6 :: [Float] -> Float
average_t6 = (/4).(sum)

average_t6_f :: [[Float]] -> [Float]
average_t6_f = map (average_t6)

-- Functie care tranforma un tuplu intr-un Row - lista
toRow_t6 :: (String, Float, Float, Float) -> Row
toRow_t6 (a,b,c,d) = a:(printf "%.2f" b):(printf "%.2f" c):(printf "%.2f" d):[]

toTable_t6 :: [(String, Float, Float, Float)] -> Table
toTable_t6 = map (toRow_t6)

-- Functie care calculeaza diferenta dintre doua numere in modul
difference :: Float -> Float -> Float
difference a b = abs (a - b)

difference_f :: [Float] -> [Float] -> [Float]
difference_f [] [] = []
difference_f (x:xs) (y:ys) = (difference x y):(difference_f xs ys)

get_difference :: Table -> [Float]
get_difference m = (difference_f (average_t6_f (second_t6_f (tuplify_t6_f (tail m)))) (average_t6_f (third_t6_f (tuplify_t6_f (tail m)))))

-- Functie care creeaza tuplurile cu care voi lucra
get_tuples :: Table -> [(String, Float, Float, Float)]
get_tuples m = (zip4 (first_t6_f (tuplify_t6_f (tail m))) (average_t6_f (second_t6_f (tuplify_t6_f (tail m)))) (average_t6_f (third_t6_f (tuplify_t6_f (tail m)))) (get_difference m))

-- Functie care sorteaza tuplurile din lista dupa cerinte
get_tuples_sorted :: Table -> [(String, Float, Float, Float)]
get_tuples_sorted m = sortBy (\(_,_,_,a) (_,_,_,b) -> compare a b) (sortBy (\(a,_,_,_) (b,_,_,_) -> compare a b) (get_tuples m))

get_steps_diff_table :: Table -> Table
get_steps_diff_table m = ["Name","Average first 4h","Average last 4h","Difference"]:(toTable_t6 (get_tuples_sorted m))

-- Task 7

-- Applies the given function to all the values
vmap :: (Value -> Value) -> Table -> Table
vmap f m = map (map f) m

-- Task 8

rmap_aux :: (Row -> Row) -> Table -> Table
rmap_aux f m = map (f) m

-- Applies the given function to all the entries
rmap :: (Row -> Row) -> [String] -> Table -> Table
rmap f s m = if (head m) == s then (rmap_aux f (tail m))
  else m

get_sleep_total :: Row -> Row
get_sleep_total r = (r !! 0) : (printf "%.2f" (sum (map read (tail r) :: [Float]))) : []


{-
    TASK SET 2
-}


-- Task 1

-- Functie care imi da indicele coloanei cautate
index1 :: Int -> Table -> ColumnName -> Int
index1 n m s =
 do
  if (head m !! n) == s then n                                                          
    else (index1 (n - 1) m s)

index2 :: Int -> Row -> ColumnName -> Int
index2 n l s =
 do
  if (l !! n) == s then n                                                          
    else (index2 (n - 1) l s)

-- Functie care verifica daca am coloana cautata in tabel
aux :: Int -> Table -> ColumnName -> Bool
aux n m s =
 do
  if (head m !! n) == s then True
    else (aux (n - 1) m s)

-- Sortez tabela dupa ColumnName
tsort :: ColumnName -> Table -> Table
tsort s m
    | aux (length (head m) - 1) m s = (head m) : (sortBy (\a b -> if (a !! (index1 (length (head m) - 1) m s)) < "A" then (compare (read (a !! (index1 (length (head m) - 1) m s)) :: Float) (read (b !! (index1 (length (head m) - 1) m s)) :: Float)) else (compare (a !! (index1 (length (head m) - 1) m s)) (b !! (index1 (length (head m) - 1) m s)))) (sortBy (\a b -> compare (a !! 0) (b !! 0)) (tail m)))
    | otherwise = [[""]]

-- Task 2

-- Concatenez cele doua tabele
vunion :: Table -> Table -> Table
vunion t1 t2 = if (head t1) == (head t2) then t1 ++ (tail t2)
    else [[""]]

-- Task 3

-- Functie care adauga randuri goale unei tabele
add_rows :: Int -> Table -> Table
add_rows 0 t1 = [(replicate (length (head t1)) "")]
add_rows n t1 = t1 ++ (add_rows (n - 1) [(replicate (length (head t1)) "")])

-- Uniunea a doua tabele  
hunion :: Table -> Table -> Table
hunion t1 t2 = if (length t1) == (length t2) then zipWith (++) t1 t2
  else if (length t1) < (length t2) then zipWith (++) ((add_rows ((length t2) - (length t1)) t1)) t2
    else if (length t1) > (length t2) then zipWith (++) t1 ((add_rows ((length t1) - (length t2)) t2)) 
      else [[""]]

-- Task 4

tjoin :: ColumnName -> Table -> Table -> Table
tjoin key_column t1 t2 = [["0"]]
  
-- Task 5

-- Functie care aplica o functie intre elementele din doua randuri
linie :: (Row -> Row -> Row) -> Row -> Row -> Row
linie op a b = op a b

-- Functie care realizeaza produsul cartezian intre un rand si o tabela 
cart :: (Row -> Row -> Row) -> Row -> Table -> Table
cart _ [] [[]] = [[]]
cart _ _ [[]] = [[]]
cart _ [[]] _ = [[]]
cart op a [x] = (linie op a x) : []
cart op a (b:bs) = (linie op a b) : (cart op a bs)

-- Functie care realizeaza produsul cartezian intre doua tabele
cart_fin :: (Row -> Row -> Row) -> Table -> Table -> Table
cart_fin _ [[]] _ = [[]]
cart_fin op [x] b = cart op x b
cart_fin op (a:as) b = (cart op a b) ++ (cart_fin op as b)

-- Functie care adauga la tabela noua obtinuta prin produsul cartezian numele noilor coloane
cartesian :: (Row -> Row -> Row) -> [ColumnName] -> Table -> Table -> Table
cartesian new_row_function new_column_names a b = new_column_names : (cart_fin new_row_function (tail a) (tail b))

-- Task 6

-- Functie care returneaza o coloana in functie de indexul ei
coloana :: Int -> [[a]] -> [a]
coloana n = map (head . drop n)

-- Functie care transforma [a] in [[a]]
construct :: Row -> Table
construct [] = []
construct (x:xs) = [x] : (construct xs) 

-- Functie care adauga la inceputul tabelei date coloanele cerute
aux_1 :: [ColumnName] -> Table -> Table
aux_1 [] t = t
aux_1 _ [[]] = [[]]
aux_1 (a:as) m = zipWith (++) (construct (coloana (index1 (length (head m) - 1) m a) m)) (aux_1 as m)

-- Sterg tabela initiala => raman doar cu coloanele cerute
projection :: [ColumnName] -> Table -> Table
projection a m = transpose (reverse (drop (length (head m)) (reverse (transpose (aux_1 a m))))) 

-- Task 7

filterTable :: (Value -> Bool) -> ColumnName -> Table -> Table
filterTable condition key_column t = (head t) : (filter ((condition) . (!! (index1 (length (head t) - 1) t key_column))) (tail t))


{-
    TASK SET 3
-}


-- 3.1

data Query =
    FromTable Table
    | AsList String Query
    | Sort String Query
    | ValueMap (Value -> Value) Query
    | RowMap (Row -> Row) [String] Query
    | VUnion Query Query
    | HUnion Query Query
    | TableJoin String Query Query
    | Cartesian (Row -> Row -> Row) [String] Query Query
    | Projection [String] Query
    | forall a. FEval a => Filter (FilterCondition a) Query -- 3.2, 3.3
    | Graph EdgeOp Query -- 3.5

class Eval a where
    eval :: a -> QResult

instance Eval Query where
    eval (FromTable table) = Table table
    -- 3.1.1
    eval (AsList colname (FromTable query)) = List (coloana (index1 (length (head query) - 1) query colname) (tail query))
    -- 3.1.2
    eval (Sort colname (FromTable query)) = Table (tsort colname query)
    -- 3.1.3
    eval (ValueMap op (FromTable query)) = Table (vmap op query)
    -- 3.1.4
    eval (RowMap op colnames (FromTable query)) = Table (colnames : (map op (tail query)))
    -- 3.1.5
    eval (VUnion (FromTable query1) (FromTable query2)) = Table (vunion query1 query2)
    -- 3.1.6
    eval (HUnion (FromTable query1) (FromTable query2)) = Table (hunion query1 query2)
     -- 3.1.7 
    eval (TableJoin colname (FromTable query1) (FromTable query2)) = Table [[]]
    -- 3.1.8
    eval (Cartesian op colnames (FromTable query1) (FromTable query2)) = Table (cartesian op colnames query1 query2)
    -- 3.1.9
    eval (Projection colnames (FromTable query)) = Table (projection colnames query)
    -- 3.3
    eval (Filter (Eq colname a) (FromTable query)) = Table ((head query) : (filter (feval (head query) (Eq colname a)) query))

    eval (Filter (Gt colname a) (FromTable query)) = Table ((filter (feval (head query) (Gt colname a)) query))

    eval (Filter (Lt colname a) (FromTable query)) = Table ((head query) : (filter (feval (head query) (Lt colname a)) query))

    eval (Filter (In colname a) (FromTable query)) = Table ((head query) : (filter (feval (head query) (In colname a)) query))

    eval (Filter (FNot a) (FromTable query)) = Table [[]]

    eval (Filter (FieldEq colname a) (FromTable query)) = Table [[]]

    -- 3.4
    eval (Graph a (FromTable query)) = Table [[]]


instance Show QResult where
    show (List l) = show l
    show (Table t) = show t

-- 3.2 & 3.3
m = Dataset.physical_activity
type FilterOp = Row -> Bool

data FilterCondition a =
    Eq String a |
    Lt String a |
    Gt String a |
    In String [a] |
    FNot (FilterCondition a) |
    FieldEq String String

class FEval a where
    feval :: [String] -> (FilterCondition a) -> FilterOp

instance FEval String where
    feval l (Eq colname ref) = g
        where g l1 = if (l1 !! (index2 (length l - 1) l colname)) == ref then True 
                else False
    
    feval l (Lt colname ref) = g
        where g l1 = if (l1 !! (index2 (length l - 1) l colname)) < ref then True 
                else False

    feval l (Gt colname ref) = g
        where g l1 = if (l1 !! (index2 (length l - 1) l colname)) > ref then True 
                else False

    feval l (In colname list) = g
        where g l1 = if elem (l1 !! (index2 (length l - 1) l colname)) list then True
                else False 

instance FEval Float where
    feval l (Eq colname ref) = g
        where g l1 = if (l1 !! (index2 (length l - 1) l colname)) == (show ref) then True 
                else False
    
    feval l (Lt colname ref) = g
        where g l1 = if (l1 !! (index2 (length l - 1) l colname)) < (show ref) then True 
                else False

    feval l (Gt colname ref) = g
        where g l1 = if (l1 !! (index2 (length l - 1) l colname)) > (show ref) then True 
                else False

    feval l (In colname list) = g
        where g l1 = if elem (l1 !! (index2 (length l - 1) l colname)) (map show (map round (map read (map show list) :: [Float]))) then True
                else False 

-- 3.4

-- where EdgeOp is defined:
type EdgeOp = Row -> Row -> Maybe Value

-- 3.5
similarities_query :: Query
similarities_query = FromTable [[]]
-- 3.6 (Typos)
correct_table :: String -> Table -> Table -> Table
correct_table col csv1 csv2 = [[]]

-- Stefan Elena-Ioana 323CB --